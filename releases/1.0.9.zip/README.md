# wp-nice-search

[![License](https://img.shields.io/packagist/l/rilwis/meta-box.svg)](https://duywp.com)
[![Version](https://img.shields.io/wordpress/plugin/v/wp-nice-search.svg)](https://wordpress.org/plugins/wp-nice-search/)
[![Total Downloads](https://img.shields.io/wordpress/plugin/dt/wp-nice-search.svg)](https://wordpress.org/plugins/wp-nice-search/)

***
## Description
Use ajax to search while you typing the text.

## Featured
* Search by Post, Page, Custom post type
* Option for shortcode.

## Installation

* Unzip the download package
* Upload `wp-nice-search` to the `/wp-content/plugins/` directory
* Activate the plugin through the 'Plugins' menu in WordPress

***
## How to use
* Use the shortcode to get the search form `[wpns_search_form]`

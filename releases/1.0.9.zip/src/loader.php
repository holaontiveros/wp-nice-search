<?php
require_once WPNS_DIR . '/vendor/autoload.php';

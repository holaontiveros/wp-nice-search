<?php
/**
 * Clean up after delete the plugin
 * @package wpns
 * @author Duy Nguyen <duyngha@gmail.com>
 * @since 1.0.0
 */

delete_option('wpns_options');